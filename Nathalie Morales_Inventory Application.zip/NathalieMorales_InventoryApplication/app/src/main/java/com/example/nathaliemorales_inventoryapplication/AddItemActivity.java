package com.example.nathaliemorales_inventoryapplication;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class AddItemActivity extends AppCompatActivity {
    private DatabaseHelper dbHelper;
    private EditText itemNameInput, skuInput, quantityInput;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_item);

        dbHelper = new DatabaseHelper(this);

        itemNameInput = findViewById(R.id.itemNameInput);
        skuInput = findViewById(R.id.skuInput);
        quantityInput = findViewById(R.id.quantityInput);
        Button saveButton = findViewById(R.id.saveButton);
        Button cancelButton = findViewById(R.id.cancelButton);

        saveButton.setOnClickListener(v -> saveItem());
        cancelButton.setOnClickListener(v -> finish());
    }

    private void saveItem() {
        String name = itemNameInput.getText().toString().trim();
        String sku = skuInput.getText().toString().trim();
        String quantityStr = quantityInput.getText().toString().trim();

        if (name.isEmpty() || sku.isEmpty() || quantityStr.isEmpty()) {
            Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            int quantity = Integer.parseInt(quantityStr);
            long result = dbHelper.addItem(name, sku, quantity);

            if (result != -1) {
                Toast.makeText(this, "Item added successfully", Toast.LENGTH_SHORT).show();
                finish();
            } else {
                Toast.makeText(this, "Failed to add item", Toast.LENGTH_SHORT).show();
            }
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Please enter a valid quantity", Toast.LENGTH_SHORT).show();
        }
    }
}
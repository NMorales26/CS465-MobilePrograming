package com.example.nathaliemorales_inventoryapplication;

import android.app.AlertDialog;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class InventoryActivity extends AppCompatActivity {
    private DatabaseHelper dbHelper;
    private TableLayout inventoryTable;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        dbHelper = new DatabaseHelper(this);
        inventoryTable = findViewById(R.id.inventoryTable);
        Button addItemButton = findViewById(R.id.addItemButton);

        addItemButton.setOnClickListener(v -> {
            Intent intent = new Intent(this, AddItemActivity.class);
            startActivity(intent);
        });

        loadInventoryData();
    }

    private void loadInventoryData() {
        // Clear existing rows except the header
        while (inventoryTable.getChildCount() > 1) {
            inventoryTable.removeViewAt(1);
        }

        Cursor cursor = dbHelper.getAllItems();
        if (cursor != null && cursor.moveToFirst()) {
            do {
                final int itemId = cursor.getInt(cursor.getColumnIndexOrThrow("id"));
                String itemName = cursor.getString(cursor.getColumnIndexOrThrow("item_name"));
                String sku = cursor.getString(cursor.getColumnIndexOrThrow("sku"));
                final int currentQuantity = cursor.getInt(cursor.getColumnIndexOrThrow("quantity"));

                TableRow row = new TableRow(this);

                // Item Name
                TextView nameView = createTextView(itemName);
                row.addView(nameView);

                // SKU
                TextView skuView = createTextView(sku);
                row.addView(skuView);

                // Quantity
                final TextView quantityView = createTextView(String.valueOf(currentQuantity));
                row.addView(quantityView);

                // Actions Button
                Button actionsButton = new Button(this);
                actionsButton.setText("ACTIONS");
                actionsButton.setOnClickListener(v -> {
                    String[] actions = {"Update Quantity", "Delete Item"};
                    new AlertDialog.Builder(this)
                            .setTitle("Choose Action")
                            .setItems(actions, (dialog, which) -> {
                                switch (which) {
                                    case 0: // Update Quantity
                                        AlertDialog.Builder builder = new AlertDialog.Builder(this);
                                        builder.setTitle("Update Quantity");

                                        final EditText input = new EditText(this);
                                        input.setHint("Enter new quantity");
                                        input.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
                                        builder.setView(input);

                                        builder.setPositiveButton("Update", (updateDialog, updateWhich) -> {
                                            String newQuantityStr = input.getText().toString().trim();

                                            try {
                                                int newQuantity = Integer.parseInt(newQuantityStr);

                                                if (newQuantity >= 0) {
                                                    if (dbHelper.updateItemQuantity(itemId, newQuantity)) {
                                                        quantityView.setText(String.valueOf(newQuantity));
                                                        Toast.makeText(this, "Quantity updated", Toast.LENGTH_SHORT).show();
                                                    } else {
                                                        Toast.makeText(this, "Failed to update quantity", Toast.LENGTH_SHORT).show();
                                                    }
                                                } else {
                                                    Toast.makeText(this, "Quantity cannot be negative", Toast.LENGTH_SHORT).show();
                                                }
                                            } catch (NumberFormatException e) {
                                                Toast.makeText(this, "Invalid input", Toast.LENGTH_SHORT).show();
                                            }
                                        });

                                        builder.setNegativeButton("Cancel", null);
                                        builder.create().show();
                                        break;
                                    case 1: // Delete Item
                                        new AlertDialog.Builder(this)
                                                .setTitle("Confirm Deletion")
                                                .setMessage("Are you sure you want to delete this item?")
                                                .setPositiveButton("Delete", (confirmDialog, confirmWhich) -> {
                                                    if (dbHelper.deleteItem(itemId)) {
                                                        loadInventoryData();
                                                        Toast.makeText(this, "Item deleted", Toast.LENGTH_SHORT).show();
                                                    } else {
                                                        Toast.makeText(this, "Failed to delete item", Toast.LENGTH_SHORT).show();
                                                    }
                                                })
                                                .setNegativeButton("Cancel", null)
                                                .create()
                                                .show();
                                        break;
                                }
                            })
                            .create()
                            .show();
                });
                row.addView(actionsButton);

                inventoryTable.addView(row);
            } while (cursor.moveToNext());

            cursor.close();
        }
    }

    private TextView createTextView(String text) {
        TextView textView = new TextView(this);
        textView.setText(text);
        textView.setPadding(8, 8, 8, 8);
        return textView;
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadInventoryData();
    }
}